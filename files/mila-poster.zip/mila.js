$(document).ready(function(){

    $("#color1").click(function(){
        $(".bg-color1").addClass("color-show");
        $(".bg-color2").removeClass("color-show");
      });

    $("#color2").click(function(){
        $(".bg-color2").addClass("color-show");
        $(".bg-color1").removeClass("color-show");
      });

    $("#shape1").click(function(){
        $(".bg-shape1").addClass("shape-show");
        $(".bg-shape2").removeClass("shape-show");
      });

    $("#shape2").click(function(){
        $(".bg-shape2").addClass("shape-show");
        $(".bg-shape1").removeClass("shape-show");
      });

    $("#text1").click(function(){
        $(".bg-text1").addClass("text-show");
        $(".bg-text2").removeClass("text-show");
      });

    $("#text2").click(function(){
        $(".bg-text2").addClass("text-show");
        $(".bg-text1").removeClass("text-show");
      });


});



