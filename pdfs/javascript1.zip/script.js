// window.alert('hello alert box!');

document.getElementById("number").innerHTML = 5/6;

const x = 4;
const y = 7;
const z = x + y
document.getElementsByClassName("sentence")[0].innerHTML = "The value of the variable z is " + z + ".";

const FirstName = "Patricia 11";
document.getElementById("name").innerHTML = "Her name is " + FirstName + ".";

document.getElementById("feeling").innerHTML = "I'm Happy!";

function changeFeeling() {
    document.getElementById("feeling").innerHTML = "I'm sad.";
};